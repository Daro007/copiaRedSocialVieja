import React from "react";
import Loading from "../Componentes/Loading";
import Perfil from "../Componentes/Perfil";

class Homepage extends React.Component {
  constructor() {
    super();
    this.state = {
      loading: true,
      personas: null,
    };
  }
  async componentDidMount() {
    const url = await "https://my-json-server.typicode.com/Daro007/jsonParaTP/usuarios";
    const response = await fetch(url);
    const data = await response.json();
    this.setState({
      personas: data,
      loading: false,
    });
    console.log(data);
  }
  render() {
    return (
      <div>
        {this.state.personas === null ? (
          <Loading
            style={
              this.state.loading === true
                ? { display: "block" }
                : { display: "none" }
            }
          ></Loading>
        ) : (
          this.state.personas.map((perfil) => (
            <Perfil key={perfil.id} persona={perfil} />
          ))
        )}
      </div>
    );
  }
}

export default Homepage;
