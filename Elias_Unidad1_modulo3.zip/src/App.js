import React, { Component } from "react";
import "./App.css";
import Registro from "./Paginas/Registro";
import Login from "./Paginas/Login";
import Homepage from "./Paginas/Homepage";
import PerfilDeUsuario from "./Paginas/PerfilDeUsuario";
import { Switch, Route } from "react-router-dom";
import Footer from "./Componentes/Footer";
import Header from "./Componentes/Header";
import BarraNav from "./Componentes/Nav";
// import { render } from "@testing-library/react";
import * as firebase from "firebase";

var firebaseConfig = {
  apiKey: "AIzaSyCsretsdv3baxGULZYtjDvOY05sN2vLxlU",
  authDomain: "tp1-m3-react.firebaseapp.com",
  databaseURL: "https://tp1-m3-react.firebaseio.com",
  projectId: "tp1-m3-react",
  storageBucket: "tp1-m3-react.appspot.com",
  messagingSenderId: "928336976773",
  appId: "1:928336976773:web:86533d8c4b21ef85ac02ec",
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

class App extends Component {
  constructor() {
    super();

    console.log(firebase.database());
  }
  render() {
    return (
      <div className="App">
        <div id="content-wrap">
          <Header />
          <BarraNav />
          <Switch>
            <Route exact path="/Registro">
              <Registro />
            </Route>
            <Route exact path="/Login">
              <Login />
            </Route>
            <Route exact path="/">
              <Homepage />
            </Route>
            <Route exact path="/usuarios/:id">
              <PerfilDeUsuario />
            </Route>
          </Switch>
        </div>
        <Footer />
      </div>
    );
  }
}

export default App;
